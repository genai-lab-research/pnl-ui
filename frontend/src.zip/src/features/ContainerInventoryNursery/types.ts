/**
 * Container Inventory Nursery Station Types
 */

export interface ContainerInventoryNurseryProps {
  /**
   * ID of the container to display nursery data for
   */
  containerId?: string;
  
  /**
   * Display name of the container
   */
  containerName?: string;
  
  /**
   * Optional CSS class name
   */
  className?: string;
}

export interface TimelineCell {
  /**
   * Whether this cell represents the current day
   */
  isActive: boolean;
  
  /**
   * Whether this cell represents a future date
   */
  isFuture: boolean;
  
  /**
   * Opacity of the cell (0-1)
   */
  opacity?: number;
}

export interface GrowthStatusCell {
  /**
   * Status of the crop in this position
   */
  status: 'sprout' | 'empty' | 'not-ok';
}

export interface GenerationBlockData {
  /**
   * Slot number (1-8 for each shelf)
   */
  slotNumber: number;
  
  /**
   * Tray ID
   */
  trayId: string;
  
  /**
   * Utilization percentage (0-100)
   */
  progressPercentage: number;
  
  /**
   * Grid size description
   */
  gridSize: string;
  
  /**
   * Number of crops in the tray
   */
  cropCount: number;
  
  /**
   * 36x10 matrix representing crop status
   */
  growthStatusMatrix: { status: 'sprout' | 'empty' | 'not-ok' }[][];
}

export interface TabOption {
  /**
   * Unique value for the tab
   */
  value: string;
  
  /**
   * Display label for the tab
   */
  label: string;
  
  /**
   * Optional icon component
   */
  icon?: React.ReactNode;
}