import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import {
  Box,
  Typography,
  Paper,
  Grid,
  CircularProgress,
  Alert,
  Breadcrumbs,
  Link,
  Container
} from '@mui/material';
import { UserAvatar } from '../../shared/components/ui/UserAvatar';
import VerticalFarmingTabGroup from '../../shared/components/ui/VerticalFarmingTabGroup';
import { TabNavigation } from '../../shared/components/ui/TabNavigation/TabNavigation';
import { GenerationBlock } from '../../shared/components/ui/GenerationBlock';
import { AddTrayBlock } from '../../shared/components/ui/AddTrayBlock';
import { UtilizationIndicator } from '../../shared/components/ui/UtilizationIndicator/UtilizationIndicator';
import { Timelaps } from '../../shared/components/ui/Timelaps';
import { inventoryManagementService } from '../../api/inventoryManagementService';
import { NurseryStation, Tray, Crop } from '../../types/inventory';
import { ContainerInventoryNurseryProps } from './types';
import { StyledHeader, StyledNavigation, StyledContainerTitle } from '../ContainerOverview/ContainerOverview.styles';
import { StatusChip } from '../../shared/components/ui/StatusChip';
import { containerService } from '../../api/containerService';
import { Container as ContainerType } from '../../shared/types/containers';

/**
 * Container Inventory Nursery Station Page
 * 
 * This page displays the nursery station inventory view for a specific container,
 * showing tray layout, utilization, and crop status with timeline navigation.
 */
export const ContainerInventoryNursery: React.FC<ContainerInventoryNurseryProps> = ({
  containerId: propContainerId,
  containerName: propContainerName
}) => {
  const { containerId: urlContainerId } = useParams<{ containerId: string }>();
  const navigate = useNavigate();
  const containerId = propContainerId || urlContainerId || 'CONT-001';
  const containerName = propContainerName || urlContainerId || 'farm-container-04';
  const [nurseryData, setNurseryData] = useState<NurseryStation | null>(null);
  const [container, setContainer] = useState<ContainerType | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [containerError, setContainerError] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState('Inventory');
  const [activeSubTab, setActiveSubTab] = useState('nursery');
  const [selectedDate, setSelectedDate] = useState<string>(new Date().toISOString().split('T')[0]);

  // Main navigation tabs (same structure as ContainerOverview)
  const tabs = [
    { id: 'Overview', label: 'Overview' },
    { id: 'Environment', label: 'Environment & Recipes' },
    { id: 'Inventory', label: 'Inventory' },
    { id: 'Devices', label: 'Devices' },
  ];

  // Inventory sub-tabs
  const inventorySubTabs = [
    { value: 'nursery', label: 'Nursery Station' },
    { value: 'cultivation', label: 'Cultivation Area' }
  ];

  // Generate timeline data for 62 days
  const generateTimelineData = () => {
    const cells = [];
    const today = new Date();
    const startDate = new Date(today);
    startDate.setDate(today.getDate() - 31); // 31 days ago
    
    for (let i = 0; i < 62; i++) {
      const cellDate = new Date(startDate);
      cellDate.setDate(startDate.getDate() + i);
      
      const isPast = cellDate < today;
      const isToday = cellDate.toDateString() === today.toDateString();
      const isFuture = cellDate > today;
      
      cells.push({
        isActive: isToday,
        isFuture: isFuture,
        opacity: isPast ? 1 : 0.4
      });
    }
    
    return {
      cells,
      startDate: startDate.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
      endDate: new Date(startDate.getTime() + 61 * 24 * 60 * 60 * 1000).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
      currentDayIndex: 31 // Today is in the middle
    };
  };

  const timelineData = generateTimelineData();

  // Convert tray data to generation block format
  const convertTrayToGenerationBlock = (tray: Tray, slotIndex: number) => {
    // Generate a 10x20 matrix for crop visualization (10 columns, 20 rows)
    const generateGrowthMatrix = () => {
      const matrix = [];
      const rows = 20;
      const cols = 10;
      const totalCells = rows * cols; // 200 total cells
      
      for (let row = 0; row < rows; row++) {
        const rowData = [];
        for (let col = 0; col < cols; col++) {
          const cropIndex = row * cols + col;
          const crop = tray.crops[cropIndex];
          
          if (crop) {
            // Determine status based on crop data
            const status: 'sprout' | 'empty' | 'not-ok' = crop.overdue_days > 0 ? 'not-ok' : 'sprout';
            rowData.push({ status });
          } else {
            rowData.push({ status: 'empty' as const });
          }
        }
        matrix.push(rowData);
      }
      return matrix;
    };

    return {
      slotNumber: slotIndex + 1,
      trayId: tray.id,
      progressPercentage: tray.utilization_percentage,
      gridSize: '10x20 Grid',
      cropCount: tray.crop_count,
      growthStatusMatrix: generateGrowthMatrix()
    };
  };

  // Calculate shelf utilization
  const calculateShelfUtilization = (shelf: Tray[]) => {
    if (shelf.length === 0) return 0;
    
    const totalSlots = 8; // 8 slots per shelf
    const occupiedSlots = shelf.length;
    const totalUtilization = shelf.reduce((sum, tray) => sum + tray.utilization_percentage, 0);
    
    // Calculate average utilization across all slots (including empty ones)
    const averageUtilization = totalUtilization / totalSlots;
    return Math.round(averageUtilization);
  };

  // Fetch container data
  const fetchContainerData = async () => {
    try {
      setContainerError(null);
      
      const response = await containerService.getContainer(containerId);
      
      if (response.error) {
        setContainerError(response.error.detail);
        return;
      }
      
      if (response.data) {
        setContainer(response.data);
      }
    } catch {
      setContainerError('Failed to fetch container data');
    } finally {
    }
  };

  // Create mock nursery data for visualization
  const createMockNurseryData = (): NurseryStation => {
    const createMockCrop = (id: string, seedType: string, overdueDays: number = 0): Crop => ({
      id,
      seed_type: seedType,
      seed_date: new Date(Date.now() - Math.random() * 30 * 24 * 60 * 60 * 1000).toISOString(),
      transplanting_date_planned: new Date(Date.now() + Math.random() * 14 * 24 * 60 * 60 * 1000).toISOString(),
      harvesting_date_planned: new Date(Date.now() + Math.random() * 45 * 24 * 60 * 60 * 1000).toISOString(),
      age: Math.floor(Math.random() * 30),
      status: overdueDays > 0 ? 'overdue' : 'growing',
      overdue_days: overdueDays,
      location: {
        type: 'tray',
        tray_id: `tray-${id}`,
        row: Math.floor(Math.random() * 36),
        column: Math.floor(Math.random() * 10),
        channel: 1,
        position: Math.floor(Math.random() * 360)
      }
    });

    const createMockTray = (id: string, slotNumber: number, shelf: 'upper' | 'lower', cropCount: number = 0): Tray => {
      const crops: Crop[] = [];
      const seedTypes = ['Lettuce', 'Arugula', 'Spinach', 'Kale', 'Basil'];
      
      for (let i = 0; i < cropCount; i++) {
        const seedType = seedTypes[Math.floor(Math.random() * seedTypes.length)];
        const overdueDays = Math.random() > 0.8 ? Math.floor(Math.random() * 5) : 0; // 20% chance of overdue
        crops.push(createMockCrop(`${id}-crop-${i}`, seedType, overdueDays));
      }

      return {
        id,
        rfid_tag: `RF${id.toUpperCase()}`,
        utilization_percentage: Math.round((cropCount / 200) * 100), // 200 max crops per tray (10x20)
        crop_count: cropCount,
        location: { shelf, slot_number: slotNumber },
        crops,
        is_empty: cropCount === 0,
        provisioned_at: new Date(Date.now() - Math.random() * 7 * 24 * 60 * 60 * 1000).toISOString()
      };
    };

    // Create mock trays for upper and lower shelves
    const upperShelf: Tray[] = [
      createMockTray('upper-tray-1', 1, 'upper', 155), // ~78% utilization
      createMockTray('upper-tray-2', 2, 'upper', 108), // ~54% utilization
      createMockTray('upper-tray-3', 3, 'upper', 174), // ~87% utilization
      createMockTray('upper-tray-4', 4, 'upper', 78), // ~39% utilization
      createMockTray('upper-tray-6', 6, 'upper', 142), // ~71% utilization
    ];

    const lowerShelf: Tray[] = [
      createMockTray('lower-tray-1', 1, 'lower', 120), // ~60% utilization
      createMockTray('lower-tray-3', 3, 'lower', 166), // ~83% utilization
      createMockTray('lower-tray-5', 5, 'lower', 98), // ~49% utilization
      createMockTray('lower-tray-7', 7, 'lower', 188), // ~94% utilization
    ];

    // Calculate overall utilization
    const totalTrays = upperShelf.length + lowerShelf.length;
    const totalUtilization = [...upperShelf, ...lowerShelf].reduce((sum, tray) => sum + tray.utilization_percentage, 0);
    const averageUtilization = Math.round(totalUtilization / totalTrays);

    return {
      utilization_percentage: averageUtilization,
      upper_shelf: upperShelf,
      lower_shelf: lowerShelf,
      off_shelf_trays: []
    };
  };

  // Fetch nursery station data
  const fetchNurseryData = async (date?: string) => {
    try {
      setLoading(true);
      const criteria = date ? { date } : {};
      const response = await inventoryManagementService.getNurseryStation(containerId, criteria);
      
      if (response.error) {
        setError(response.error.detail);
        // Use mock data when API fails
        setNurseryData(createMockNurseryData());
      } else if (response.data) {
        // Check if data is empty and use mock data
        const hasTrays = response.data.upper_shelf.length > 0 || response.data.lower_shelf.length > 0;
        if (!hasTrays) {
          setNurseryData(createMockNurseryData());
        } else {
          setNurseryData(response.data);
        }
        setError(null);
      } else {
        // No data returned, use mock data
        setNurseryData(createMockNurseryData());
      }
    } catch {
      setError('Failed to fetch nursery data');
      // Use mock data when fetch fails
      setNurseryData(createMockNurseryData());
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchContainerData();
    fetchNurseryData(selectedDate);
  }, [containerId, selectedDate]);

  // Handle tab navigation
  const handleTabChange = (tabId: string) => {
    if (tabId === 'Overview') {
      navigate(`/containers/${containerId}`);
    } else {
      setActiveTab(tabId);
    }
  };


  if (loading) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" minHeight="400px">
        <CircularProgress />
      </Box>
    );
  }

  if (error) {
    return (
      <Box p={3}>
        <Alert severity="error">{error}</Alert>
      </Box>
    );
  }

  return (
    <Box sx={{ bgcolor: '#F7F9FD', minHeight: '100vh' }}>
      {/* Header */}
      <StyledHeader>
        <Container maxWidth="xl">
          <StyledNavigation>
            <Breadcrumbs sx={{ '& .MuiBreadcrumbs-separator': { color: '#6B7280' } }}>
              <Link color="#6B7280" href="/containers" sx={{ textDecoration: 'none', fontWeight: 500 }}>
                Container Management
              </Link>
              <Typography color="#374151" sx={{ fontWeight: 500 }}>
                {container?.name || containerName}
              </Typography>
            </Breadcrumbs>
            <UserAvatar 
              src="/api/placeholder/32/32"
              alt="User Avatar"
              size={32} 
            />
          </StyledNavigation>

          {/* Container Title Section */}
          <Box sx={{ mt: 3, mb: 2, display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
            <Box>
              <StyledContainerTitle variant="h4">
                {container?.name || containerName}
              </StyledContainerTitle>
            </Box>
            {container && (
              <Box display="flex" alignItems="center" gap={1} sx={{ color: '#6B7280', fontSize: '14px' }}>
                <Box
                  component="span"
                  sx={{
                    width: 16,
                    height: 16,
                    backgroundColor: '#666',
                    borderRadius: '2px',
                  }}
                />
                <Typography variant="body2">
                  {container.type === 'physical' ? 'Physical' : 'Virtual'}
                </Typography>
                <Typography variant="body2" color="textSecondary">
                  {container.tenant}
                </Typography>
                <Typography variant="body2" color="textSecondary" sx={{ textTransform: 'capitalize' }}>
                  {container.purpose}
                </Typography>
                <StatusChip 
                  status={container.status === 'active' ? 'Connected' : 'Inactive'} 
                />
                <Typography variant="body2" color="textSecondary">
                  {container.location?.address}
                </Typography>
              </Box>
            )}
          </Box>

          {/* Tab Navigation */}
          <TabNavigation
            tabs={tabs}
            activeTabId={activeTab}
            onTabChange={handleTabChange}
          />
        </Container>
      </StyledHeader>

      {/* Main Content */}
      <Container maxWidth="xl" sx={{ py: 3 }}>
        {containerError && (
          <Alert severity="error" sx={{ mb: 3 }}>
            Failed to load container information: {containerError}
          </Alert>
        )}
        
        <Paper sx={{ bgcolor: '#FFFFFF', border: '1px solid #E4E4E7', borderRadius: 2, p: 3 }}>
          {/* Utilization Summary */}
          <Box sx={{ display: 'flex', justifyContent: 'center', mb: 3 }}>
            
            <UtilizationIndicator 
              percentage={nurseryData?.utilization_percentage || 0}
              label="Nursery Station  Utilization:"
            />
          </Box>

          {/* Sub-tabs */}
          <Box sx={{ display: 'flex', justifyContent: 'flex-end', mb: 2 }}>
            <VerticalFarmingTabGroup
              options={inventorySubTabs}
              value={activeSubTab}
              onChange={setActiveSubTab}
            />
          </Box>

          {/* Timeline */}
          <Box sx={{ 
            mb: 4, 
            width: '100%', 
            overflow: 'hidden',
            '& > div': {
              width: '100% !important',
              maxWidth: '100%',
              '& > div': {
                width: '100% !important',
                '& > div:first-of-type': {
                  width: '100% !important',
                  maxWidth: '100%'
                }
              }
            }
          }}>
            <Timelaps
              cells={timelineData.cells}
              startDate={timelineData.startDate}
              endDate={timelineData.endDate}
              currentDayIndex={timelineData.currentDayIndex}
            />
          </Box>

          {/* Nursery Layout */}
          {nurseryData && (
            <>
              {/* Upper Shelf */}
              <Box sx={{ mb: 4 }}>
                <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
                  <Typography variant="h6" sx={{ fontWeight: 600 }}>
                    
                  </Typography>
                  <UtilizationIndicator 
                    percentage={calculateShelfUtilization(nurseryData.upper_shelf)}
                    label="Upper Shelf Utilization:"
                  />
                </Box>
                <Grid container spacing={2}>
                  {Array.from({ length: 8 }, (_, index) => {
                    const tray = nurseryData.upper_shelf.find(t => t.location.slot_number === index + 1);
                    return (
                      <Grid item xs={12} sm={6} md={3} lg={1.5} key={`upper-${index}`}>
                        {tray ? (
                          <GenerationBlock
                            {...convertTrayToGenerationBlock(tray, index)}
                          />
                        ) : (
                          <AddTrayBlock
                            slotNumber={index + 1}
                            onAddTrayClick={() => console.log(`Add tray to slot ${index + 1}`)}
                          />
                        )}
                      </Grid>
                    );
                  })}
                </Grid>
              </Box>

              {/* Lower Shelf */}
              <Box sx={{ mb: 4 }}>
                <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
                  <Typography variant="h6" sx={{ fontWeight: 600 }}>
                    
                  </Typography>
                  <UtilizationIndicator 
                    percentage={calculateShelfUtilization(nurseryData.lower_shelf)}
                    label="Lower Shelf Utilization:"
                  />
                </Box>
                <Grid container spacing={2}>
                  {Array.from({ length: 8 }, (_, index) => {
                    const tray = nurseryData.lower_shelf.find(t => t.location.slot_number === index + 1);
                    return (
                      <Grid item xs={12} sm={6} md={3} lg={1.5} key={`lower-${index}`}>
                        {tray ? (
                          <GenerationBlock
                            {...convertTrayToGenerationBlock(tray, index)}
                          />
                        ) : (
                          <AddTrayBlock
                            slotNumber={index + 1}
                            onAddTrayClick={() => console.log(`Add tray to slot ${index + 1}`)}
                          />
                        )}
                      </Grid>
                    );
                  })}
                </Grid>
              </Box>

              {/* Off-Shelf Trays */}
              {nurseryData.off_shelf_trays.length > 0 && (
                <Box>
                  <Typography variant="h6" sx={{ mb: 2, fontWeight: 600 }}>
                    Currently off the Shelf(s)
                  </Typography>
                  <Grid container spacing={2}>
                    {nurseryData.off_shelf_trays.map((tray, index) => (
                      <Grid item xs={12} sm={6} md={3} lg={1.5} key={`off-shelf-${index}`}>
                        <GenerationBlock
                          {...convertTrayToGenerationBlock(tray, index)}
                        />
                      </Grid>
                    ))}
                  </Grid>
                </Box>
              )}
            </>
          )}
        </Paper>
      </Container>
    </Box>
  );
};