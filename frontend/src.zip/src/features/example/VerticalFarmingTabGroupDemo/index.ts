export { default } from './VerticalFarmingTabGroupDemo';
