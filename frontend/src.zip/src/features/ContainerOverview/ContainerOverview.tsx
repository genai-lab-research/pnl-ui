import React, { useState, useEffect } from 'react';
import {
  Box,
  Container,
  Grid,
  Typography,
  Breadcrumbs,
  Link,
} from '@mui/material';
import { useParams, useNavigate } from 'react-router-dom';
import {
  TabNavigation,
  TimeRangeSelector,
  UserAvatar,
  StatusChip,
  TemperatureDisplay,
  YieldBlock,
  CropsTable,
  ActivityLogPanel,
  ContainerSettingsPanel,
  ContainerInfoPanel,
  PaginationBlock,
} from '../../shared/components/ui';
import { containerService, inventoryService } from '../../api';
import { Container as ContainerData } from '../../shared/types/containers';
import { CropData } from '../../shared/components/ui/CropsTable/types';
import { ActivityLogEntry } from '../../shared/components/ui/ActivityLogPanel/types';
import { ContainerSettings } from '../../shared/components/ui/ContainerSettingsPanel/types';
import {
  StyledHeader,
  StyledNavigation,
  StyledContainerTitle,
  StyledMetricsSection,
  StyledCropsSection,
  StyledInfoSection,
} from './ContainerOverview.styles';

/**
 * ContainerOverview page component
 * 
 * @returns JSX element
 */
export const ContainerOverview: React.FC = () => {
  const { containerId } = useParams<{ containerId: string }>();
  const navigate = useNavigate();
  const [container, setContainer] = useState<ContainerData | null>(null);
  const [crops, setCrops] = useState<CropData[]>([]);
  const [metrics, setMetrics] = useState<any>(null);
  const [activities, setActivities] = useState<ActivityLogEntry[]>([]);
  const [settings, setSettings] = useState<ContainerSettings>({});
  const [timeRange, setTimeRange] = useState<string>('Week');
  const [activeTab, setActiveTab] = useState<string>('Overview');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const tabs = [
    { id: 'Overview', label: 'Overview' },
    { id: 'Environment', label: 'Environment & Recipes' },
    { id: 'Inventory', label: 'Inventory' },
    { id: 'Devices', label: 'Devices' },
  ];


  // Mock data for development
  const mockMetrics = {
    airTemperature: 20,
    humidity: 65,
    co2Level: 860,
    yield: 51,
    nurseryUtilization: 75,
    cultivationUtilization: 90,
  };

  const mockCrops: CropData[] = [
    {
      id: '1',
      seed_type: 'Salanova Countkevi',
      seed_date: '2025-01-30',
      transplanting_date_planned: '2025-01-30',
      harvesting_date_planned: '2025-01-01',
      age: 26,
      overdue_days: 0,
      cultivation_area_count: 40,
      nursery_table_count: 30,
    },
    {
      id: '2',
      seed_type: 'Arugula',
      seed_date: '2025-01-30',
      transplanting_date_planned: '2025-01-30',
      harvesting_date_planned: '2025-01-01',
      age: 33,
      overdue_days: 0,
      cultivation_area_count: 55,
      nursery_table_count: 10,
    },
    {
      id: '3',
      seed_type: 'Rex Butterhead',
      seed_date: '2025-01-30',
      transplanting_date_planned: '2025-01-30',
      harvesting_date_planned: '2025-01-01',
      age: 24,
      overdue_days: 0,
      cultivation_area_count: 65,
      nursery_table_count: 10,
    },
    {
      id: '4',
      seed_type: 'Lollo Rossa',
      seed_date: '2025-01-30',
      transplanting_date_planned: '2025-01-30',
      harvesting_date_planned: '2025-01-01',
      age: 18,
      overdue_days: 0,
      cultivation_area_count: 35,
      nursery_table_count: 25,
    },
  ];

  const mockActivities: ActivityLogEntry[] = [
    {
      id: '1',
      description: 'Seeded Salanova Countkevi in Nursery',
      timestamp: '2025-04-15T22:35:00Z',
      user: 'Emily Chen',
    },
    {
      id: '2',
      description: 'Data synced',
      timestamp: '2025-04-15T22:34:00Z',
    },
    {
      id: '3',
      description: 'Environment mode switched to Auto',
      timestamp: '2025-04-15T22:34:00Z',
    },
    {
      id: '4',
      description: 'Container created',
      timestamp: '2025-04-15T21:36:00Z',
    },
    {
      id: '5',
      description: 'Container maintenance performed',
      timestamp: '2025-04-10T22:30:00Z',
      user: 'Maintenance Team',
    },
  ];

  const mockSettings: ContainerSettings = {
    shadowServiceEnabled: false,
    externalSystemsConnected: true,
    faIntegration: 'Alpha',
    awsEnvironment: 'Dev',
    mbaiEnvironment: 'Disabled',
  };

  useEffect(() => {
    const fetchData = async () => {
      if (!containerId) return;

      setLoading(true);
      try {
        // Fetch container data
        const containerResponse = await containerService.getContainer(containerId);
        if (containerResponse.data && !containerResponse.error) {
          setContainer(containerResponse.data);
        }

        // Fetch metrics
        const metricsResponse = await inventoryService.getInventoryMetrics(containerId, {});
        if (metricsResponse.data && !metricsResponse.error) {
          // Map API response to frontend metric names and use mock data for unavailable metrics
          setMetrics({
            // Use mock data for metrics not available from API
            airTemperature: mockMetrics.airTemperature,
            humidity: mockMetrics.humidity,
            co2Level: mockMetrics.co2Level,
            yield: mockMetrics.yield,
            // Use real API data for utilization metrics
            nurseryUtilization: metricsResponse.data.nursery_station_utilization,
            cultivationUtilization: metricsResponse.data.cultivation_area_utilization,
          });
        } else {
          setMetrics(mockMetrics);
        }

        // Fetch crops
        const cropsResponse = await inventoryService.getCrops(containerId, {});
        if (cropsResponse.data && !cropsResponse.error && cropsResponse.data.length > 0) {
          setCrops(cropsResponse.data);
        } else {
          setCrops(mockCrops);
        }

        // Set mock data for activities and settings
        setActivities(mockActivities);
        setSettings(mockSettings);
      } catch (err) {
        setError('Failed to load container data');
        console.error('Error fetching container data:', err);
        
        // Use mock data on error for development
        setContainer({
          id: containerId,
          name: 'farm-container-04',
          type: 'physical',
          tenant: 'tenant-123',
          purpose: 'development',
          location: { city: 'Lviv', country: 'Ukraine', address: 'Live' },
          status: 'active',
          seed_types: ['Someseeds', 'sunflower', 'Someseeds', 'Someseeds'],
          created: '2025-01-30T09:36:00Z',
          modified: '2025-01-30T11:14:00Z',
          has_alert: false,
          shadow_service_enabled: false,
          ecosystem_connected: true,
          notes: 'Primary production container for Farm A.',
        });
        setMetrics(mockMetrics);
        setCrops(mockCrops);
        setActivities(mockActivities);
        setSettings(mockSettings);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [containerId]);

  const handleSettingChange = (key: string, value: boolean | string) => {
    setSettings(prev => ({ ...prev, [key]: value }));
    // TODO: Update settings via API
  };

  // Handle tab navigation
  const handleTabChange = (tabId: string) => {
    if (tabId === 'Inventory') {
      navigate(`/containers/${containerId}/inventory/nursery`);
    } else {
      setActiveTab(tabId);
    }
  };

  if (loading) {
    return (
      <Container maxWidth="xl" sx={{ py: 4 }}>
        <Typography>Loading container data...</Typography>
      </Container>
    );
  }

  if (error && !container) {
    return (
      <Container maxWidth="xl" sx={{ py: 4 }}>
        <Typography color="error">Error: {error}</Typography>
      </Container>
    );
  }

  return (
    <Box sx={{ backgroundColor: '#F7F9FE', minHeight: '100vh' }}>
      {/* Header */}
      <StyledHeader>
        <Container maxWidth="xl">
          <StyledNavigation>
            <Breadcrumbs sx={{ '& .MuiBreadcrumbs-separator': { color: '#6B7280' } }}>
              <Link color="#6B7280" href="/containers" sx={{ textDecoration: 'none', fontWeight: 500 }}>
                Container Dashboard
              </Link>
              <Typography color="#374151" sx={{ fontWeight: 500 }}>
                {container?.name || 'Container'}
              </Typography>
            </Breadcrumbs>
            <UserAvatar 
              src="/api/placeholder/32/32"
              alt="User Avatar"
              size={32} 
            />
          </StyledNavigation>

          {/* Container Title Section */}
          <Box sx={{ mt: 3, mb: 2, display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
            <Box>
              <StyledContainerTitle variant="h4">
                {container?.name || 'farm-container-04'}
              </StyledContainerTitle>
              <Box display="flex" alignItems="center" gap={2} mt={1}>
                <Box display="flex" alignItems="center" gap={1}>                                  
                </Box>                
              </Box>
            </Box>
            <Box display="flex" alignItems="center" gap={1} sx={{ color: '#6B7280', fontSize: '14px' }}>
              <Box
                    component="span"
                    sx={{
                      width: 16,
                      height: 16,
                      backgroundColor: '#666',
                      borderRadius: '2px',
                    }}
                  />
              <Typography variant="body2">
                    {container?.type === 'physical' ? 'Physical' : 'Virtual'}
                  </Typography>
              <Typography variant="body2" color="textSecondary">
                  {container?.tenant}
                </Typography>
                <Typography variant="body2" color="textSecondary" sx={{ textTransform: 'capitalize' }}>
                  {container?.purpose}
                </Typography>
                <StatusChip 
                  status={container?.status === 'active' ? 'Connected' : 'Inactive'} 
                />
                <Typography variant="body2" color="textSecondary">
                  {container?.location?.address}
                </Typography>
            </Box>
          </Box>

          {/* Tab Navigation */}
          <TabNavigation
            tabs={tabs}
            activeTabId={activeTab}
            onTabChange={handleTabChange}
          />
        </Container>
      </StyledHeader>

      {/* Main Content */}
      <Container maxWidth="xl" sx={{ py: 3 }}>
        {/* Metrics Section */}
        <StyledMetricsSection>
          <Box display="flex" justifyContent="space-between" alignItems="center" mb={2}>
            <Typography variant="h6">Container Metrics</Typography>
            <TimeRangeSelector
              selectedRange={timeRange as 'Week' | 'Month' | 'Quarter' | 'Year'}
              onRangeChange={(range) => setTimeRange(range)}
            />
          </Box>
          <Grid container spacing={2}>
            <Grid item xs={12} sm={6} md={2}>
              <TemperatureDisplay
                currentTemperature={metrics?.airTemperature || 20}
                targetTemperature={22}
                unit="°C"
              />
            </Grid>
            <Grid item xs={12} sm={6} md={2}>
              <TemperatureDisplay
                currentTemperature={metrics?.humidity || 65}
                targetTemperature={70}
                title="Humidity"
                unit="%"
              />
            </Grid>
            <Grid item xs={12} sm={6} md={2}>
              <TemperatureDisplay
                currentTemperature={metrics?.co2Level || 860}
                targetTemperature={900}
                title="CO2 Level"
                unit=" ppm"
              />
            </Grid>
            <Grid item xs={12} sm={6} md={2}>
              <YieldBlock
                label="Yield"
                value={`${metrics?.yield || 51}KG`}
                increment="+1.5Kg"
              />
            </Grid>
            <Grid item xs={12} sm={6} md={2}>
              <YieldBlock
                label="Nursery Station Utilization"
                value={`${metrics?.nurseryUtilization || 75}%`}
              />
            </Grid>
            <Grid item xs={12} sm={6} md={2}>
              <YieldBlock
                label="Cultivation Area Utilization"
                value={`${metrics?.cultivationUtilization || 90}%`}
              />
            </Grid>
          </Grid>
        </StyledMetricsSection>

        {/* Crops Section */}
        <StyledCropsSection>
          <Typography variant="h6" gutterBottom>
            Crops
          </Typography>
          <CropsTable
            crops={crops}
            onRowClick={(crop) => console.log('Clicked crop:', crop)}
          />
          <Box mt={2}>
            <PaginationBlock
              currentPage={1}
              totalPages={1}
              onPageChange={() => {}}
            />
          </Box>
        </StyledCropsSection>

        {/* Information Section */}
        <StyledInfoSection>
          <Grid container spacing={3}>
            <Grid item xs={12} md={4}>
              <ContainerInfoPanel
                container={container}
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <ContainerSettingsPanel
                settings={settings}
                onSettingChange={handleSettingChange}
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <ActivityLogPanel
                activities={activities}
                maxHeight={500}
              />
            </Grid>
          </Grid>
        </StyledInfoSection>
      </Container>
    </Box>
  );
};

export default ContainerOverview;