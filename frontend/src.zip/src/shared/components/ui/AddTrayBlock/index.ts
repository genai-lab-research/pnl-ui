export * from './AddTrayBlock';
export * from './types';
export { AddTrayBlock as default } from './AddTrayBlock';