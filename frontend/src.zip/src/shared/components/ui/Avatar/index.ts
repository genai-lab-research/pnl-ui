export { Avatar } from './Avatar';
export type { AvatarProps } from './types';