import React, { useMemo } from 'react';
import { 
  Container, 
  TopStack, 
  SlotBadge,
  CardBody,
  HeaderRow,
  TrayId,
  Percentage,
  ProgressBar,
  GrowthGrid,
  GridRow,
  Cell,
  FooterRow,
  GridSize,
  CropCount
} from './styles';
import { GenerationBlockProps } from './types';
import { generateGrowthMatrix } from './utils';

export const GenerationBlock: React.FC<GenerationBlockProps> = ({
  slotNumber = 4,
  trayId = 'TR-15199256',
  progressPercentage = 75,
  gridRows = 20,
  gridColumns = 10,
  totalCrops = 170,
  className
}) => {
  const growthMatrix = useMemo(() => 
    generateGrowthMatrix(gridRows, gridColumns, totalCrops),
    [gridRows, gridColumns, totalCrops]
  );
  
  return (
    <Container className={className}>
      <TopStack>
        <SlotBadge>SLOT {slotNumber}</SlotBadge>
      </TopStack>
      
      <CardBody>
        <HeaderRow>
          <TrayId>{trayId}</TrayId>
          <Percentage>{progressPercentage}%</Percentage>
        </HeaderRow>
        
        <ProgressBar $progress={progressPercentage} />
        
        <GrowthGrid>
          {growthMatrix.rows.map((row, rowIndex) => (
            <GridRow key={`row-${rowIndex}`}>
              {row.map((cellStatus, cellIndex) => (
                <Cell 
                  key={`cell-${rowIndex}-${cellIndex}`} 
                  $status={cellStatus} 
                />
              ))}
            </GridRow>
          ))}
        </GrowthGrid>
        
        <FooterRow>
          <GridSize>{gridColumns}x{gridRows} Grid</GridSize>
          <CropCount>{totalCrops} crops</CropCount>
        </FooterRow>
      </CardBody>
    </Container>
  );
};