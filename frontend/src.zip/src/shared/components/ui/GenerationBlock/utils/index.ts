export { default as generateGrowthMatrix } from './generateGrowthMatrix';
export * from './generateGrowthMatrix';