export { ContainerGenerationBlock } from './ContainerGenerationBlock';
export type { ContainerGenerationBlockProps } from './types';