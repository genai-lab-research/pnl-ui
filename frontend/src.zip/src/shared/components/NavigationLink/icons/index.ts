export { default as ArrowForwardIcon } from './ArrowForwardIcon';
